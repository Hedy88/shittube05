<table width="180" cellspacing="0" cellpadding="0" border="0" bgcolor="#eaf0fa" align="center">
			<tbody><tr>
				<td><img src="./img/box_login_tl.gif" width="5" height="5"></td>
				<td><img src="./img/pixel.gif" width="1" height="5"></td>
				<td><img src="./img/box_login_tr.gif" width="5" height="5"></td>
			</tr>
			<tr>
				<td><img src="./img/pixel.gif" width="5" height="1"></td>
				<td style="padding: 5px; text-align: center;" width="170">
				<div style="font-weight: bold; font-size: 13px;">User Advertisment</div>
				
				<a href="#"><img src="./img/useradph.png" style="border: 5px solid #FFFFFF; margin-top: 10px;" width="147" height="251"></a>
								
				<div style="font-size: 12px; font-weight: bold; margin-bottom: 5px; padding-top: 5px;"><a href="discord.php">Submit your user ads in our discord!</a></div>
				
								
				</td>
				<td><img src="./img/pixel.gif" width="5" height="1"></td>
			</tr>
			<tr>
				<td><img src="./img/box_login_bl.gif" width="5" height="5"></td>
				<td><img src="./img/pixel.gif" width="1" height="5"></td>
				<td><img src="./img/box_login_br.gif" width="5" height="5"></td>
			</tr>
		</tbody></table>