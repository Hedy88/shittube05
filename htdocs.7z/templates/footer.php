<table cellspacing="0" cellpadding="10" border="0" align="center">
	<tbody><tr>
		<td valign="center" align="center"><span class="footer"><a href="whats_new.php">What's New</a> | <a href="help.php">Help</a> | <a href="devs.php">Developers</a> <img src="./img/new.gif"> | <a href="guidelines.php">Community Guidelines</a> | <a href="./discord.php">Discord</a> 
		<br><br>shitTube <?php echo date("Y"); ?> | <a href="./libs/rss/rss.php"><img src="./img/rss.gif" style="vertical-align: text-top;" width="36" height="14" border="0"></a></span></td>
	</tr>
</tbody></table>