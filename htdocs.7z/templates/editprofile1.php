<div class="formTitle">My profile</div>

<div class="tableSubTitle">Edit About Me</div>
<form method="post" action="./libs/profiles/editaboutme.php">
    <textarea name="lol" placeholder="lol"></textarea><br><br>
    <button type="submit">Save</button>
</form>