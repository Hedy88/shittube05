<table width="595" cellspacing="0" cellpadding="0" border="0" bgcolor="#E5ECF9" align="center">
			<tbody><tr>
				<td><img src="./img/box_login_tl.gif" width="5" height="5"></td>
				<td width="100%"><img src="./img/pixel.gif" width="1" height="5"></td>
				<td><img src="./img/box_login_tr.gif" width="5" height="5"></td>
			</tr>
			<tr>
				<td><img src="./img/pixel.gif" width="5" height="1"></td>
				<td style="padding: 5px 0px 5px 0px;">
				
								
				<table width="100%" cellspacing="0" cellpadding="0" border="0">
					<tbody><tr valign="top">
					<td style="border-right: 1px dashed #369; padding: 0px 10px 10px 10px; color: #444;" width="33%">
					<div style="font-size: 16px; font-weight: bold; margin-bottom: 5px;"><a href="my_videos_upload.php">Upload</a></div>
					Quickly upload and tag videos in almost any video format.
					</td>
					<td style="border-right: 1px dashed #369; padding: 0px 10px 10px 10px; color: #444;" width="33%">
					<div style="font-size: 16px; font-weight: bold; margin-bottom: 5px;"><a href="browse.php">Watch</a></div>
					Instantly find and watch 1000's of fast streaming videos.
					</td>
					<td style="padding: 0px 10px 10px 10px; color: #444;" width="33%">
					<div style="font-size: 16px; font-weight: bold; margin-bottom: 5px;"><a href="my_friends_invite.php">Share</a></div>
					Easily share your videos with family, friends, or co-workers.
					</td>
					</tr>
				</tbody></table>

									
				</td>
				<td><img src="./img/pixel.gif" width="5" height="1"></td>
			</tr>
			<tr>
				<td><img src="./img/box_login_bl.gif" width="5" height="5"></td>
				<td><img src="./img/pixel.gif" width="1" height="5"></td>
				<td><img src="./img/box_login_br.gif" width="5" height="5"></td>
		   </tr>
	</tbody>
</table>