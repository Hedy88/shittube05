<div class="tableSubTitle">What's this? | 11/04/2022</div>
<br> 
I made this in my freetime because of bored of popular video sites (Vidlii / BitView) being Russian propaganda centers under the new owners
<br>
the site is now in public beta, if you care.
<br><br>
- <a href="./profile.php?u=rgb">rgb</a>
