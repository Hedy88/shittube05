<table width="180" cellspacing="0" cellpadding="0" border="0" bgcolor="#FFCC99" align="center">
			<tbody><tr>
				<td><img src="./img/box_login_tl.gif" width="5" height="5"></td>
				<td><img src="./img/pixel.gif" width="1" height="5"></td>
				<td><img src="./img/box_login_tr.gif" width="5" height="5"></td>
			</tr>
			<tr>
				<td><img src="./img/pixel.gif" width="5" height="1"></td>
				<td style="padding: 5px; text-align: center;" width="170">
				<div style="font-weight: bold; font-size: 13px;">Site Launch Video Contest!</div>
				
				<a href="#"><img src="./img/1contest.jpg" style="border: 5px solid #FFFFFF; margin-top: 10px;" width="80" height="60"></a>
				
				<div style="font-size: 16px; font-weight: bold; padding-top: 5px;"><a href="monthly_contest.php">Joke Tutorials</a></div>
				<div style="font-size: 11px; padding: 10px 0px 5px 0px;">In celebration of shitTube launching, the shitTube team is proud to announce there 1st video contest.</div>
				
								
				<div style="font-size: 12px; font-weight: bold; margin-bottom: 5px;"><a href="signup.php">Join the contest now!</a></div>
				
								
				</td>
				<td><img src="./img/pixel.gif" width="5" height="1"></td>
			</tr>
			<tr>
				<td><img src="./img/box_login_bl.gif" width="5" height="5"></td>
				<td><img src="./img/pixel.gif" width="1" height="5"></td>
				<td><img src="./img/box_login_br.gif" width="5" height="5"></td>
			</tr>
		</tbody></table>