<td width="180">

    <table width="180" cellspacing="0" cellpadding="0" border="0" bgcolor="#E5ECF9" align="center">
        <tbody>
            <tr>
                <td><img src="./img/box_login_tl.gif" width="5" height="5"></td>
                <td width="170"><img src="./img/pixel.gif" width="1" height="5"></td>
                <td><img src="./img/box_login_tr.gif" width="5" height="5"></td>
            </tr>
            <tr>
                <td><img src="./img/pixel.gif" width="5" height="1"></td>
                <td style="padding: 5px;" align="center">
                    <div style="padding-bottom: 10px;"><a href="signup.php">Sign up</a> or <a href="login.php">log in</a> to add <?php echo $username; ?></div> as a friend.</div>
                </td>
                <td><img src="./img/pixel.gif" width="5" height="1"></td>
            </tr>
            <tr>
                <td><img src="./img/box_login_bl.gif" width="5" height="5"></td>
                <td><img src="./img/pixel.gif" width="1" height="5"></td>
                <td><img src="./img/box_login_br.gif" width="5" height="5"></td>
            </tr>
        </tbody>
    </table>

    <div style="padding-top: 15px;">
        <?php include './templates/last4.php'; ?>
    </div>
    
<td><img src="./img/pixel.gif" width="5" height="1"></td>