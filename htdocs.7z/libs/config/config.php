<?php
// db stuff (gets passed to auth.php)
$mysql_data['db_host'] = 'localhost';
$mysql_data['db_user'] = 'root';
$mysql_data['db_pass'] = '';
$mysql_data['db_name'] = 'shittube2';

$version = 'alpha1.0.2';
$sitename = $_SERVER['HTTP_HOST'];

$ffmpeg = 'C:/ffmpeg/ffmpeg.exe';
$ffprobe = 'C:/ffmpeg/ffprobe.exe';
?>
