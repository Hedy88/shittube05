<?php 
include './libs/config/config.php';
include './libs/config/db_auth.php';
?>
<html>
    <head>
        <?php include './meta.php'; ?>
    </head>
    <body>
        <?php include './templates/vidlist1.php'; ?>
    </body>
</html>